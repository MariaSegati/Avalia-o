package Exer;

public class diegosz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
